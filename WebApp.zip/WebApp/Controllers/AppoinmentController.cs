﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class AppoinmentController : Controller
    {
        private IAppoinmentRepo _appoinmentRepo;
        private IUnitOfWork _unitOfWork;

        public AppoinmentController(IAppoinmentRepo repo,
            IUnitOfWork unitOfWork
            )
        {
            _appoinmentRepo = repo;
            _unitOfWork = unitOfWork;
        }

        public async Task<IActionResult> Index()
        {
            var list =await _appoinmentRepo.List();
            var data =list.Select(n => new AppoinmentViewModel
            {
                Capacity = n.Capacity,
                Date = n.Date,
                Id = n.Id,
                IsConfirmed = n.IsConfirmed,
                Confirmation = n.IsConfirmed == null ? Confirmation.NoAction : 
                    (n.IsConfirmed == true? Confirmation.Confirmed : Confirmation.Denied )

            }).ToList();
            return View(data);
        }

        public ActionResult Create()
        {
            return View();
        }

        public async Task<ActionResult> View(int id)
        {
            var data = await _appoinmentRepo.View(id);
            var vm = new ScheduleViewModel();
            vm.Appoinment = new AppoinmentViewModel
            {
                Capacity = data.Capacity,
                Date = data.Date,
                Id = data.Id,
                IsConfirmed = data.IsConfirmed
            };
            vm.Passengers = new List<PassengerViewModel>();
            foreach (var passenger in data.Passengers)
            {
                vm.Passengers.Add(new PassengerViewModel
                {
                    FirstName = passenger.FirstName,
                    LastName = passenger.LastName,
                    Weight = passenger.Weight
                });
            }

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(AppoinmentViewModel viewModel)
        {
             _appoinmentRepo.Create(new Core.Entities.Appointment
            {
                Capacity = viewModel.Capacity,
                Date = viewModel.Date,
                IsConfirmed = null
            });
            _unitOfWork.Save();
            return View(new AppoinmentViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(ScheduleViewModel viewModel)
        {
            if (viewModel.Appoinment.Confirmation != Confirmation.NoAction)
            {
                _appoinmentRepo.SetConfirm(viewModel.Appoinment.Id, viewModel.Appoinment.Confirmation == Confirmation.Denied ? false : true);
                _unitOfWork.Save();
            }
            return RedirectToAction("Index");
        }
    }
}
