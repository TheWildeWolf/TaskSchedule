﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class PassengerController : Controller
    {
        private IPassengerRepo _passengerRepo;
        private IUnitOfWork _unitOfWork;
        private IScheduleRepo _scheduleRepo;
        private IAppoinmentRepo _appoinmentRepo;

        public PassengerController(IPassengerRepo repo,
            IUnitOfWork unitOfWork,
            IScheduleRepo scheduleRepo,
            IAppoinmentRepo appoinmentRepo
            )
        {
            _appoinmentRepo = appoinmentRepo;
            _passengerRepo = repo;
            _unitOfWork = unitOfWork;
            _scheduleRepo = scheduleRepo;
        }
        public async Task<IActionResult> Index()
        {
            var data = await _passengerRepo.List();
            var vm=data.Select(x => new PassengerViewModel
            {
                FirstName = x.FirstName,
                LastName = x.LastName,
                State = x.State,
                Weight = x.Weight,
                Id = x.Id
            }).ToList();
            return View(vm);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(PassengerViewModel viewModel)
        {
            _passengerRepo.Create(new Core.Entities.Passenger
            {
                FirstName = viewModel.FirstName,
                LastName = viewModel.LastName,
                Weight = viewModel.Weight,
                State = Core.Entities.PassengerState.Open
            });
            _unitOfWork.Save();
            ModelState.Clear();
            return View(new PassengerViewModel());
        }


        public async Task<ActionResult> View(int id)
        {
            var data = await _passengerRepo.View(id);
            var appoinments = await _appoinmentRepo.GetAppoinments();
            var vm = new PassengerViewModel
            {
                FirstName = data.FirstName,
                LastName = data.LastName,
                State = data.State,
                Weight = data.Weight,
                ScheduledTime = data.Appointment != null ? data.Appointment.Date.ToString() : "",
                Appoinments = new SelectList(appoinments, "Id", "Date")
            };

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Update(int id,int appoinmentId)
        {
            _scheduleRepo.Create(id, appoinmentId);
            _unitOfWork.Save();
            return RedirectToAction("Index");
        }
    }
}
